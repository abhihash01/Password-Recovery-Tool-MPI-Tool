this
is 
a 
hash
multiple statements